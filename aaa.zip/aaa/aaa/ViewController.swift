
//Use core data index to fetch a specific item from core data
//
//
//My swift code below when loaded places 3 items in the core data entity named "UserName". When the user enters a number into textfield enterT I want the label labelName to display it. So when the user enters 1 the label should display jessica biel because Jesical Biel is the first name entered. Someone stated the suggestion below to solve this problem. I dont know exactly how to do this.
//
//
//Convert the entered number to Int. If this succeeds pass the integer to joke and fetch the record matching the idx attribute.

    import UIKit
    import CoreData

    class ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet var labelName : UILabel!
    @IBOutlet var enterT : UITextField!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate //Singlton instance
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        openDatabse()
        
        
        
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        guard let index = Int(textField.text!) else {
            // display an alert about invalid text
            return
        }
        joke(at: index )
    }

    func joke(at index : Int) {
        let fetchRequest = NSFetchRequest<Users>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "idx == %d", Int32(index))
        do {
            if let user = try context.fetch(fetchRequest).first {
                print(user.username)
            }
        } catch {
            print("Could not fetch \(error) ")
        }
    }
    
    
    func openDatabse()
    {
        context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        let newUser2 = NSManagedObject(entity: entity!, insertInto: context)
        let newUser3 = NSManagedObject(entity: entity!, insertInto: context)
        saveData(UserDBObj: newUser, UserDBObj2: newUser2, UserDBObj3: newUser3)
        
    }
    
    func saveData(UserDBObj:NSManagedObject,UserDBObj2:NSManagedObject,UserDBObj3:NSManagedObject)
    {
        UserDBObj.setValue("kim kardashian", forKey: "username")
        UserDBObj2.setValue("jessica biel", forKey: "username")
        UserDBObj3.setValue("Hailey Rienhart", forKey: "username")
        
        
        
        
        print("Storing Data..")
        do {
            try context.save()
        } catch {
            print("Storing data Failed")
        }
        
        fetchData()
    }
    
    func fetchData()
    {
        print("Fetching Data..")
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
                let userName = data.value(forKey: "username") as! String
                
                print("User Name is : "+userName)
            }
        } catch {
            print("Fetching data Failed")
        }
    }}
